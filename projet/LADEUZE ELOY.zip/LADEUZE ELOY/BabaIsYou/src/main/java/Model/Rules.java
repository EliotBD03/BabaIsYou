package Model;
//cette énumération servira dans BigAlgorithm
//elle représente les tous les objets en dehors des blocs de règle
public enum Rules
{
    BABA, WALL, ROCK,GOOP, STOP, PUSH, YOU, IS, FLAG, WIN, SINK, KILL, LAVA, NONE
}
